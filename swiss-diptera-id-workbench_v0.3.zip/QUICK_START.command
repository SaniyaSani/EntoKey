#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install -U pip
pip install -r requirements.txt
export PYTHONPATH="$(pwd)/src"
python -m uvicorn app.api:app --reload
